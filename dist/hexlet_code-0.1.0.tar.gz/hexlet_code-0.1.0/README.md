### Hexlet tests and linter status:
[![Actions Status](https://github.com/1gwh1te/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/1gwh1te/python-project-49/actions)