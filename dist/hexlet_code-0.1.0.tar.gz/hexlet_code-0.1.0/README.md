### Hexlet tests and linter status:
[![Actions Status](https://github.com/1gwh1te/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/1gwh1te/python-project-49/actions)
### Codeclimate
[![Maintainability](https://api.codeclimate.com/v1/badges/f3a6c80e2119f5532076/maintainability)](https://codeclimate.com/github/1gwh1te/python-project-49/maintainability)
### Asciinema brain-even
[![asciicast](https://asciinema.org/a/YJ1XuO1OsO2wICJENrmIRSZuv.svg)](https://asciinema.org/a/YJ1XuO1OsO2wICJENrmIRSZuv)
### Asciinema brain-calc
[![asciicast](https://asciinema.org/a/WIOUYABIQYwEpGzUZLYAiAf14.svg)](https://asciinema.org/a/WIOUYABIQYwEpGzUZLYAiAf14)
### Asciinema brain-gcd
[![asciicast](https://asciinema.org/a/e4oHPkYneleAnKrnZPWkiWRB2.svg)](https://asciinema.org/a/e4oHPkYneleAnKrnZPWkiWRB2)
### Asciinema brain-progression
[![asciicast](https://asciinema.org/a/LQyPsJA55qlzFU8WWc9jYeibq.svg)](https://asciinema.org/a/LQyPsJA55qlzFU8WWc9jYeibq)
### Asciinema brain-prime
[![asciicast](https://asciinema.org/a/WSYA5tX5DDBgoVbQn24IxFZIA.svg)](https://asciinema.org/a/WSYA5tX5DDBgoVbQn24IxFZIA)
