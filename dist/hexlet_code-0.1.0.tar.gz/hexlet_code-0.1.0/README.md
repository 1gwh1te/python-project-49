### Hexlet tests and linter status:
[![Actions Status](https://github.com/1gwh1te/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/1gwh1te/python-project-49/actions)
### Codeclimate
<a href="https://codeclimate.com/github/1gwh1te/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f3a6c80e2119f5532076/maintainability" /></a><a href="https://codeclimate.com/github/1gwh1te/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f3a6c80e2119f5532076/maintainability" /></a>
### Asciinema
[![asciicast](https://asciinema.org/a/YJ1XuO1OsO2wICJENrmIRSZuv.svg)](https://asciinema.org/a/YJ1XuO1OsO2wICJENrmIRSZuv)
